package com.example.devsecops;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AppTest {

    @Test
    void testAppWorks() {
        assertTrue(true);
    }
}

